import numpy as np
import matplotlib.pyplot as plt

temps = np.array([0.03, 0.06, 0.125, 0.25, 0.5])
borne_theorique = temps / 2
L_emp = np.array([2.9e-4, 4.8e-4, 9.3e-4, 1.8e-3, 3.6e-3])
rmse = np.array([1.5e-5, 2.5e-5, 6.9e-5, 1.2e-4, 2.5e-4])

plt.figure(figsize=(7,5))
plt.plot(temps, borne_theorique, 'r--o', label="Theoretical bound |t|/2")
plt.plot(temps, L_emp, 'b-o', label="Empirical sensitivity $L_{emp}$")
plt.plot(temps, rmse, 'g-o', label="RMSE (vs reference)")
plt.xlabel("Temperature t")
plt.ylabel("Value")
plt.title("Empirical calibration of softmax Lipschitz bound")
plt.legend()
plt.grid(True, ls="--", alpha=0.6)
plt.tight_layout()
plt.savefig("softmax_calib_en.png", dpi=300)
