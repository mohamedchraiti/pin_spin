
import numpy as np, pandas as pd, math, time
np.random.seed(42)

def softmax_rows(x):
    x_max = np.max(x, axis=-1, keepdims=True)
    e = np.exp(x - x_max)
    return e / np.sum(e, axis=-1, keepdims=True)

def softmax_attention(Q, K, V, t):
    S = t * (Q @ K.T)
    W = softmax_rows(S)
    return W @ V, W

def linear_feature_map_elu(x):
    return np.where(x>0, x, np.exp(x)-1) + 1.0

def linear_attention(Q, K, V, feature_map):
    PhiQ = feature_map(Q)
    PhiK = feature_map(K)
    S = PhiK.T @ V
    numerator = PhiQ @ S
    denom = PhiQ @ (PhiK.T @ np.ones((PhiK.shape[0],1)))
    denom = denom + 1e-12
    return numerator / denom

def fro_norm(mat):
    return np.linalg.norm(mat.ravel(), ord=2)

# sparsemax (row-wise, small n)
def sparsemax(z):
    z = np.array(z)
    original_shape = z.shape
    z_flat = z.reshape(-1, original_shape[-1])
    out = np.zeros_like(z_flat)
    for i, zs in enumerate(z_flat):
        z_sorted = np.sort(zs)[::-1]
        cums = np.cumsum(z_sorted)
        k = 0
        for j in range(1, len(zs)+1):
            t = (cums[j-1] - 1.0)/j
            if z_sorted[j-1] > t:
                k = j
        tau = (np.sum(z_sorted[:k]) - 1.0)/k if k>0 else 0.0
        out[i] = np.maximum(zs - tau, 0.0)
    return out.reshape(original_shape)

def soft_topk_weights(S_row, k, smooth=1.0):
    kth = np.partition(S_row, -k)[-k] if k < len(S_row) else np.min(S_row)
    mask = 1.0 / (1.0 + np.exp(-(S_row - kth) / smooth))
    masked = S_row * mask
    ex = np.exp(masked - np.max(masked))
    w = ex / np.sum(ex)
    return w

def soft_topk_attention(Q,K,V,t,k,smooth=1.0):
    S = t * (Q @ K.T)
    n = S.shape[0]
    W = np.zeros_like(S)
    for i in range(n):
        W[i,:] = soft_topk_weights(S[i,:], k, smooth)
    return W @ V, W

# Parameters (reduced)
d_k = 64; d_v = 64
delta_norm = 1e-3

# 1) Temperature sweep (reduced trials)
def sweep_t_experiment(trials=4, n=128, t_list=None):
    if t_list is None:
        t_list = [0.03, 0.06, 0.125, 0.25, 0.5]
    rows = []
    for trial in range(trials):
        Q = np.random.randn(n, d_k).astype(np.float32) * 0.1
        K = np.random.randn(n, d_k).astype(np.float32) * 0.1
        V = np.random.randn(n, d_v).astype(np.float32)
        rnorm = np.linalg.norm(V, axis=1); m = rnorm.max()
        if m>0: V = (V/m).astype(np.float32)
        Y_true, Wt = softmax_attention(Q,K,V,0.125)
        deltaQ = np.random.randn(*Q.shape).astype(np.float32)
        deltaQ *= (delta_norm / (fro_norm(deltaQ) + 1e-30))
        dq = fro_norm(deltaQ)
        for t in t_list:
            O_t, _ = softmax_attention(Q,K,V,t)
            rmse = fro_norm(O_t - Y_true) / math.sqrt(n * d_v)
            O_tp, _ = softmax_attention(Q+deltaQ, K, V, t)
            Lemp = fro_norm(O_tp - O_t) / (dq + 1e-30)
            rows.append({"trial": trial+1, "n": n, "t": t, "rmse": rmse, "L_emp": Lemp})
    return pd.DataFrame(rows)

# 2) Dependence on n (reduced n list)
def dependence_n_experiment(n_list=[64,128,256,512], trials=2):
    rows = []
    for n in n_list:
        for trial in range(trials):
            Q = np.random.randn(n, d_k).astype(np.float32) * 0.1
            K = np.random.randn(n, d_k).astype(np.float32) * 0.1
            V = np.random.randn(n, d_v).astype(np.float32)
            rnorm = np.linalg.norm(V, axis=1); m = rnorm.max()
            if m>0: V = (V/m).astype(np.float32)
            deltaQ = np.random.randn(*Q.shape).astype(np.float32); deltaQ *= (delta_norm / (fro_norm(deltaQ)+1e-30))
            dq = fro_norm(deltaQ)
            O_s, _ = softmax_attention(Q,K,V,0.125)
            O_sp, _ = softmax_attention(Q+deltaQ,K,V,0.125)
            Ls = fro_norm(O_sp - O_s) / (dq + 1e-30)
            O_l = linear_attention(Q,K,V, linear_feature_map_elu)
            O_lp = linear_attention(Q+deltaQ,K,V, linear_feature_map_elu)
            Ll = fro_norm(O_lp - O_l) / (dq + 1e-30)
            rows.append({"trial": trial+1, "n": n, "aggregator":"softmax", "L_emp": Ls})
            rows.append({"trial": trial+1, "n": n, "aggregator":"linear_elu", "L_emp": Ll})
    return pd.DataFrame(rows)

# 3) Perturb parts (reduced trials)
def perturb_parts_experiment(n=128, trials=4):
    rows = []
    for trial in range(trials):
        Q = np.random.randn(n, d_k).astype(np.float32) * 0.1
        K = np.random.randn(n, d_k).astype(np.float32) * 0.1
        V = np.random.randn(n, d_v).astype(np.float32)
        rnorm = np.linalg.norm(V, axis=1); m = rnorm.max()
        if m>0: V = (V/m).astype(np.float32)
        deltaQ = np.random.randn(*Q.shape).astype(np.float32); deltaQ *= (delta_norm / (fro_norm(deltaQ)+1e-30))
        deltaK = np.random.randn(*K.shape).astype(np.float32); deltaK *= (delta_norm / (fro_norm(deltaK)+1e-30))
        deltaV = np.random.randn(*V.shape).astype(np.float32); deltaV *= (delta_norm / (fro_norm(deltaV)+1e-30))
        dq = fro_norm(deltaQ); dk = fro_norm(deltaK); dv = fro_norm(deltaV)
        O = softmax_attention(Q,K,V,0.125)[0]
        Oq = softmax_attention(Q+deltaQ,K,V,0.125)[0]
        Ok = softmax_attention(Q,K+deltaK,V,0.125)[0]
        Ov = softmax_attention(Q,K,V+deltaV,0.125)[0]
        rows.append({"trial":trial+1,"part":"Q","L_emp":fro_norm(Oq-O)/(dq+1e-30),"aggregator":"softmax"})
        rows.append({"trial":trial+1,"part":"K","L_emp":fro_norm(Ok-O)/(dk+1e-30),"aggregator":"softmax"})
        rows.append({"trial":trial+1,"part":"V","L_emp":fro_norm(Ov-O)/(dv+1e-30),"aggregator":"softmax"})
        # linear
        Ol = linear_attention(Q,K,V, linear_feature_map_elu)
        Olq = linear_attention(Q+deltaQ,K,V, linear_feature_map_elu)
        Olk = linear_attention(Q,K+deltaK,V, linear_feature_map_elu)
        Olv = linear_attention(Q,K,V+deltaV, linear_feature_map_elu)
        rows.append({"trial":trial+1,"part":"Q","L_emp":fro_norm(Olq-Ol)/(dq+1e-30),"aggregator":"linear_elu"})
        rows.append({"trial":trial+1,"part":"K","L_emp":fro_norm(Olk-Ol)/(dk+1e-30),"aggregator":"linear_elu"})
        rows.append({"trial":trial+1,"part":"V","L_emp":fro_norm(Olv-Ol)/(dv+1e-30),"aggregator":"linear_elu"})
    return pd.DataFrame(rows)

# 4) Estimate constants (reduced samples)
def estimate_softmax_L(t=0.125, m=30, dim=32, delta_scale=1e-6):
    ratios = []
    for i in range(m):
        alpha = np.random.randn(dim)
        d = np.random.randn(dim)
        d = d * (delta_scale / (np.linalg.norm(d)+1e-30))
        s = np.exp(t*alpha - np.max(t*alpha)); s = s/np.sum(s)
        s2 = np.exp(t*(alpha+d) - np.max(t*(alpha+d))); s2 = s2/np.sum(s2)
        ratios.append(np.linalg.norm(s2 - s) / (np.linalg.norm(d) + 1e-30))
    return {"mean_ratio": float(np.mean(ratios)), "max_ratio": float(np.max(ratios)), "theoretical_bound": abs(t)/2.0}

def estimate_aggregator_L_A(agg_fn, n=32, trials=40, delta_scale=1e-6):
    ratios = []
    for i in range(trials):
        V = np.random.randn(n, d_v)
        out = agg_fn(V)
        dV = np.random.randn(*V.shape)
        dV = dV * (delta_scale / (np.linalg.norm(dV.ravel())+1e-30))
        out2 = agg_fn(V + dV)
        ratios.append(np.linalg.norm(out2 - out) / (np.linalg.norm(dV.ravel()) + 1e-30))
    return {"mean_ratio": float(np.mean(ratios)), "max_ratio": float(np.max(ratios))}

def agg_mean(V): return np.mean(V, axis=0, keepdims=True).repeat(V.shape[0], axis=0)
def agg_sum(V): return np.sum(V, axis=0, keepdims=True).repeat(V.shape[0], axis=0)
def agg_weighted_by_fixed_W(V, W_row):
    w = W_row.reshape(1,-1)
    agg = (w @ V)
    return np.repeat(agg, V.shape[0], axis=0)

# 5) sparsemax and soft-top-k (reduced trials)
def sparsemax_attention(Q,K,V,t):
    S = t * (Q @ K.T)
    W = np.array([sparsemax(row) for row in S])
    return W @ V, W

def soft_topk_attention(Q,K,V,t,k,smooth=1.0):
    S = t * (Q @ K.T)
    n = S.shape[0]
    W = np.zeros_like(S)
    for i in range(n):
        W[i,:] = soft_topk_weights(S[i,:], k, smooth)
    return W @ V, W

def sparse_softtop_experiment(n=128, trials=3, k_list=[8,16], smooth_list=[0.5,1.0]):
    rows = []
    for trial in range(trials):
        Q = np.random.randn(n, d_k).astype(np.float32) * 0.1
        K = np.random.randn(n, d_k).astype(np.float32) * 0.1
        V = np.random.randn(n, d_v).astype(np.float32)
        rnorm = np.linalg.norm(V, axis=1); m = rnorm.max()
        if m>0: V = (V/m).astype(np.float32)
        Y_true, _ = softmax_attention(Q,K,V,0.125)
        deltaQ = np.random.randn(*Q.shape).astype(np.float32); deltaQ *= (delta_norm / (fro_norm(deltaQ)+1e-30)); dq = fro_norm(deltaQ)
        O_spm, _ = sparsemax_attention(Q,K,V,0.125)
        rows.append({"trial":trial+1,"method":"sparsemax","rmse":fro_norm(O_spm - Y_true)/math.sqrt(n*d_v),"L_emp":fro_norm(sparsemax_attention(Q+deltaQ,K,V,0.125)[0]-O_spm)/(dq+1e-30)})
        for k in k_list:
            for s in smooth_list:
                O_stk, _ = soft_topk_attention(Q,K,V,0.125,k,s)
                rows.append({"trial":trial+1,"method":f"soft_topk_k{k}_s{s}","rmse":fro_norm(O_stk - Y_true)/math.sqrt(n*d_v),"L_emp":fro_norm(soft_topk_attention(Q+deltaQ,K,V,0.125,k,s)[0]-O_stk)/(dq+1e-30)})
    return pd.DataFrame(rows)

# Run reduced experiments
t_sweep_df = sweep_t_experiment(trials=4, n=128)
t_sweep_summary = t_sweep_df.groupby("t").agg(rmse_mean=("rmse","mean"), rmse_std=("rmse","std"), Lemp_mean=("L_emp","mean"), Lemp_std=("L_emp","std")).reset_index()

n_dep_df = dependence_n_experiment(n_list=[64,128,256,512], trials=2)
n_dep_summary = n_dep_df.groupby(["n","aggregator"]).agg(Lemp_mean=("L_emp","mean"), Lemp_std=("L_emp","std")).reset_index()

perturb_df = perturb_parts_experiment(n=128, trials=4)
perturb_summary = perturb_df.groupby(["aggregator","part"]).agg(Lemp_mean=("L_emp","mean"), Lemp_std=("L_emp","std")).reset_index()

softmax_L_est = estimate_softmax_L(t=0.125, m=30, dim=32, delta_scale=1e-6)
agg_mean_L = estimate_aggregator_L_A(lambda V: agg_mean(V), n=32, trials=40, delta_scale=1e-6)
agg_sum_L = estimate_aggregator_L_A(lambda V: agg_sum(V), n=32, trials=40, delta_scale=1e-6)
random_W = np.abs(np.random.randn(32)); random_W = random_W / random_W.sum()
agg_weighted_L = estimate_aggregator_L_A(lambda V: agg_weighted_by_fixed_W(V, random_W), n=32, trials=40, delta_scale=1e-6)

sparse_df = sparse_softtop_experiment(n=128, trials=3, k_list=[8,16], smooth_list=[0.5,1.0])
sparse_summary = sparse_df.groupby("method").agg(rmse_mean=("rmse","mean"), rmse_std=("rmse","std"), Lemp_mean=("L_emp","mean"), Lemp_std=("L_emp","std")).reset_index()

# Save CSVs
t_sweep_df.to_csv("/mnt/data/exp1_t_sweep_trials_small.csv", index=False)
t_sweep_summary.to_csv("/mnt/data/exp1_t_sweep_summary_small.csv", index=False)
n_dep_df.to_csv("/mnt/data/exp2_n_dependence_trials_small.csv", index=False)
n_dep_summary.to_csv("/mnt/data/exp2_n_dependence_summary_small.csv", index=False)
perturb_df.to_csv("/mnt/data/exp3_perturb_parts_trials_small.csv", index=False)
perturb_summary.to_csv("/mnt/data/exp3_perturb_parts_summary_small.csv", index=False)
sparse_df.to_csv("/mnt/data/exp5_sparse_softtop_trials_small.csv", index=False)
sparse_summary.to_csv("/mnt/data/exp5_sparse_softtop_summary_small.csv", index=False)

# Print concise summaries
print("1) Temperature sweep summary:\n", t_sweep_summary.to_string(index=False, float_format="{:.6g}".format))
print("\n2) Dependence on n summary:\n", n_dep_summary.to_string(index=False, float_format="{:.6g}".format))
print("\n3) Perturbation parts summary:\n", perturb_summary.to_string(index=False, float_format="{:.6g}".format))
print("\n4) Empirical softmax Lipschitz and aggregator L estimates:\n", softmax_L_est)
print("agg_mean:", agg_mean_L, "agg_sum:", agg_sum_L, "agg_weighted:", agg_weighted_L)
print("\n5) Sparsemax / soft-top-k summary:\n", sparse_summary.to_string(index=False, float_format="{:.6g}".format))
print("\nCSV files saved under /mnt/data/ (small versions).")
