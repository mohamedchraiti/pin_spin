#!/usr/bin/env python3
# fe_heat_trace.py
# Finite-element radial model for detecting log(u) terms in heat trace.
# Usage: python fe_heat_trace.py
import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla
from numpy.linalg import lstsq
import matplotlib.pyplot as plt

def assemble_FE_matrices(N, alpha=1.0, m=0, c=0.0, R=1.0):
    h = R/N
    nodes = np.linspace(0, R, N+1)
    Ke_ref = np.array([[1,-1],[-1,1]])/h
    Me_ref = np.array([[2,1],[1,2]])*h/6
    K = sp.lil_matrix((N+1,N+1))
    M = sp.lil_matrix((N+1,N+1))
    for e in range(N):
        r1, r2 = nodes[e], nodes[e+1]
        rm = 0.5*(r1+r2)
        w = rm*h
        Ke = Ke_ref * w
        Me = Me_ref * w
        V = (m+c-alpha)**2/(rm**2+1e-14)
        Ke += Me*V
        idx = [e, e+1]
        for i in range(2):
            for j in range(2):
                K[idx[i],idx[j]] += Ke[i,j]
                M[idx[i],idx[j]] += Me[i,j]
    keep = np.arange(1,N)
    K = K[keep,:][:,keep].tocsr()
    M = M[keep,:][:,keep].tocsr()
    return K, M

def compute_FE_eigs(alpha=1.0, c=0.0, Mmax=6, N=300, nev=4):
    eigs = []
    for m in range(-Mmax, Mmax+1):
        K,M = assemble_FE_matrices(N, alpha=alpha, m=m, c=c)
        try:
            vals = spla.eigsh(K, M=M, k=nev, which='SM', tol=1e-6, maxiter=2000, return_eigenvectors=False)
            vals = np.real(vals)
            vals = np.clip(vals, 0, None)
            eigs.extend(vals.tolist())
        except Exception as e:
            continue
    return np.array(sorted(eigs))

def heat_trace(eigs,u_vals):
    return np.sum(np.exp(-np.outer(u_vals,eigs)),axis=1)

def fit_log_model(u,H):
    X = np.vstack([np.ones_like(u), u, u**2, np.log(u)]).T
    coeffs, _, _, _ = lstsq(X,H,rcond=None)
    Hfit = X.dot(coeffs)
    resid = np.sqrt(np.mean((H-Hfit)**2))
    return coeffs,resid,Hfit

if __name__ == "__main__":
    alpha=1.0; c=0.0; Mmax=6; N=300
    eigs = compute_FE_eigs(alpha=alpha, c=c, Mmax=Mmax, N=N, nev=4)
    u_vals = np.logspace(-6,-2,40)
    H = heat_trace(eigs,u_vals)
    coeffs,resid,Hfit = fit_log_model(u_vals,H)
    print("Fitted coeffs A0,A1,A2,B:",coeffs)
    print("Residual RMS:",resid)
    # Save figures
    plt.figure(figsize=(6,4))
    plt.loglog(u_vals,H,'o',label="H(u) data")
    plt.loglog(u_vals,Hfit,'-',label="fit with log term")
    plt.xlabel("u"); plt.ylabel("H(u)")
    plt.legend(); plt.grid(True)
    plt.savefig("H_vs_fit.png", dpi=200, bbox_inches='tight')
    plt.close()
    plt.figure(figsize=(6,4))
    plt.semilogx(u_vals,H-Hfit,label="Residual")
    plt.xlabel("u"); plt.ylabel("Residual H-Hfit")
    plt.legend(); plt.grid(True)
    plt.savefig("residual.png", dpi=200, bbox_inches='tight')
